
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Parking {
    private Map<String, Car> cars;
    private int capacity;

    public Parking(int capacity) {
        this.capacity = capacity;
        this.cars = new HashMap<>();
    }

    public String addCar(Car car) {
        String result = "";
        if (this.cars.containsKey(car.getRegistrationNumber())) {
            result = "Car with that registration number, already exists!";
        } else if (this.cars.size() == capacity) {
            System.out.println("Parking is full!");
        } else {
            this.cars.put(car.getRegistrationNumber(), car);
            result = String.format("Successfully added new car %s %s", car.getMake(), car.getRegistrationNumber());
        }
        return result;
    }

    public String removeCar(String registrationNumber) {
        String result = "";
        if (!this.cars.containsKey(registrationNumber)) {
            result = "Car with that registration number, doesn't exists!";
        } else {
            this.cars.remove(registrationNumber);
            result = "Successfully removed " + registrationNumber;
        }
        return result;
    }

    public Car getCar(String registrationNumber) {
        return this.cars.get(registrationNumber);
    }

    public String removeSetOfRegistrationNumber(List<String> registrationNumbers) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < registrationNumbers.size(); i++) {
            if (i == registrationNumbers.size() - 1) {
                sb.append(removeCar(registrationNumbers.get(i)));
                break;
            }
            sb.append(removeCar(registrationNumbers.get(i))).append(System.lineSeparator());
        }
        return sb.toString();
    }

    public int getCount() {
        return this.cars.size();
    }
}
